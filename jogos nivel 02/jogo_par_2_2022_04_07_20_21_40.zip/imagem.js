let imagemEstrada;
let imagemAtor01;
let imagemCarro01;
let imagemCarro02;
let imagemCarro03;

function preload(){
  imagemEstrada= loadImage("imagem/estrada.png");
  imagemAtor01=loadImage("imagem/ator-1.png");
  imagemCarro01=loadImage("imagem/carro-1.png");
  imagemCarro02=loadImage("imagem/carro-2.png");
  imagemCarro03=loadImage("imagem/carro-3.png");
  imagemCarros=[imagemCarro01,imagemCarro02,imagemCarro03,imagemCarro01,imagemCarro02,imagemCarro03]
}