function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(imagemEstrada);
  mostraAtor01();
  movimentaAtor01();
  voltaPosicao();
  mostraCarros();
  movimentoCarros();
  colisao1();
  incluiPontos();
  marcaPontos();
}














